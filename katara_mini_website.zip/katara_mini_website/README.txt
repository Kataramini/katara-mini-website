KATARA MINI WEBSITE

Open index.html in a browser to preview the site.

To publish it:
1. Ask a parent/guardian or trusted adult to help choose and manage a website host.
2. Upload index.html to the host.
3. The host will give you a public URL to share.

The audition form is intentionally marked COMING SOON. It does not collect or send information. Before accepting applications from people under 18, have a parent/guardian help set up and manage a secure form. Collect only what is necessary; do not ask for addresses, school names, phone numbers, passwords, or private social handles.
